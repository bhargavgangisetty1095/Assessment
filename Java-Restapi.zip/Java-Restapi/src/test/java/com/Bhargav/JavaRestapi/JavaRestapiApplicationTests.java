package com.Bhargav.JavaRestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
