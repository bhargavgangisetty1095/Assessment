package com.Bhargav.JavaRestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaRestapiApplication.class, args);
	}

}
