package com.Bhargav.JavaRestapi.service;

import java.util.List;

import com.Bhargav.JavaRestapi.model.Student;

public interface ApiService {
	Student createStudent(Student product);

	Student updateStudent(Student product) throws Throwable;

    List < Student > getAllStudent();

    Student getStudentById(long productId) throws Throwable;

    void deleteStudent(long id) throws Throwable;
}
