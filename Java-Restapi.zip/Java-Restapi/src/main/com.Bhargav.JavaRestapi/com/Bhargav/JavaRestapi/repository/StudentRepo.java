package com.Bhargav.JavaRestapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Bhargav.JavaRestapi.model.Student;

public interface StudentRepo extends MongoRepository<Student, Long> {

}
