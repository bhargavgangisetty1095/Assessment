package com.Bhargav.JavaRestapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Bhargav.JavaRestapi.model.Model;
import com.Bhargav.JavaRestapi.service.itemService;


@RestController
public class ItemController {
	@Autowired
    private itemService productService;

    @GetMapping("/items")
    public ResponseEntity < List < Model >> getAllProduct() {
        return ResponseEntity.ok().body(productService.getAllProduct());
    }
	
    @GetMapping("/items/{id}")
    public ResponseEntity < Model > getProductById(@PathVariable long id) throws Throwable {
        return ResponseEntity.ok().body(productService.getProductById(id));
    }
    @PostMapping("/items")
    public ResponseEntity < Model > createProduct(@RequestBody Model product) {
        return ResponseEntity.ok().body(this.productService.createProduct(product));
    }

    @PutMapping("/items/{id}")
    public ResponseEntity < Model > updateProduct(@PathVariable long id, @RequestBody Model product) throws Throwable {
        product.setId(id);
        return ResponseEntity.ok().body(this.productService.updateProduct(product));
    }
    @DeleteMapping("/item/{id}")
    public HttpStatus deleteProduct(@PathVariable long id) throws Throwable {
        ((ItemController) this.productService).deleteProduct(id);
        return HttpStatus.OK;
    }

}
