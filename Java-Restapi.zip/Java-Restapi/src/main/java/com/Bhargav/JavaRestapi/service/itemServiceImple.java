package com.Bhargav.JavaRestapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Bhargav.JavaRestapi.model.Model;
import com.Bhargav.JavaRestapi.repository.modelRepo;

@Service
@Transactional
public class itemServiceImple implements itemService{
	
	@Autowired
    private modelRepo productRepository;


    public Model createProduct(Model product) {
        return productRepository.save(product);
    }

    public Model updateProduct(Model product) throws Throwable{
        Optional < Model > productDb = this.productRepository.findById(product.getId());

        if (productDb.isPresent()) {
        	Model productUpdate = productDb.get();
            productUpdate.setId(product.getId());
            productUpdate.setName(product.getName());
            productUpdate.setGrade(product.getGrade());
            productRepository.save(productUpdate);
            return productUpdate;
        } else {
            throw new Exception("Record not found with id : " + product.getId());
        }
    }

    public List < Model > getAllProduct() {
        return this.productRepository.findAll();
    }

    public Model getProductById(long productId) throws Throwable {

        Optional < Model > productDb = this.productRepository.findById(productId);

        if (productDb.isPresent()) {
            return productDb.get();
        } else {
           throw new Exception("Record not found with id : " + productId);
        }
    }

    public void deleteProduct(long productId) throws Exception {
        Optional < Model > productDb = this.productRepository.findById(productId);

        if (productDb.isPresent()) {
            this.productRepository.delete(productDb.get());
        } else {
        	throw new Exception("Record not found with id : " + productId);
        }

    }
}
