package com.Bhargav.JavaRestapi.service;

import java.util.List;

import com.Bhargav.JavaRestapi.model.Model;

public interface itemService {
		
		Model createProduct(Model product);

		Model updateProduct(Model product) throws Throwable;

	    List < Model > getAllProduct();

	    Model getProductById(long productId) throws Throwable;

	    void deleteProduct(long id) throws Throwable;
	

}
