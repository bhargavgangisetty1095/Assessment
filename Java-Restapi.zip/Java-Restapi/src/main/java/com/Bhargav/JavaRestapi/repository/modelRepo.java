package com.Bhargav.JavaRestapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Bhargav.JavaRestapi.model.Model;


public interface modelRepo extends MongoRepository<Model, Long> {

}
